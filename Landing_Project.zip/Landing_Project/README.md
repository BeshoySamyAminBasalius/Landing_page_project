# Landing Page Project


The code in this repository is meant to satisfy the 1st project rubric of the Front Ent Web Developer nanodegree.
Landing page is the conversion of a static page to a page that allows some sort of interaction. The dynamicity is achieved through javascript.

Starter code taken from udacity [repository](https://github.com/udacity/fend/tree/refresh-2019/projects/landing-page).

This project has the scope of converting a static web page in a single interactive page.

It uses javascript to dynamically create navbar links based on the content, when a section is in the viewport it show the active state of that section.

There are 4 sections that have been added to the page.